# RoboLabs API

This project was bootstrapped with `wave init` command.

## Running the app

### 1. Install poetry environment
Installing poetry environment will install all the dependencies required for the project.

If you don't have poetry installed on your machine, you can install it with the following command:
```bash
pip install poetry
```
Then, you can initiate the poetry environment with the following command:
```bash
poetry install
```

### 2. Create a `.env` file
Create a `.env` file in the `src` directory of the project. You can use the `.env.example` file as a template.
Replace the placeholder values in `.env.example` file with your own.

### 3. Run the app

You can run the app with the following command:
```bash
poetry run 
